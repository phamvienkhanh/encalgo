#include <iostream>
#include <cstdlib>

#include "pvkenc.h"

extern "C" {
#include "unif01.h"
#include "bbattery.h"
}

unsigned int myrand(void)
{
    return GetNextWord();
}

void printWord(word32 w) {
    printf("%.8x\n", w);
}

int main(int, char**) {
    
    SetupPerm();

    unif01_Gen *gen;
    const char* name = "PVK Perm";
    gen = unif01_CreateExternGenBits((char*)name, myrand);
    bbattery_Crush(gen);
    unif01_DeleteExternGenBits(gen);

    return 0;
}
