
typedef unsigned int word32;

word32 GetNextWord();
void SetupPerm();

