
#include "pvkenc.h"

#define STATE_SIZE 28
#define STATE_COL 7
#define STATE_ROW 4
#define KEY_SIZE 8
#define NONCE_SIZE 4
#define NUM_ROUND 20

#define ROTL32(w, r) ((w << r) | (w >> (32u - r)))


static const word32 RC[] = {
    0x1FFFFFFF, 0x2FFFFFFF, 0x3FFFFFFF, 0x4FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
    0x5FFFFFFF, 0x6FFFFFFF, 0x7FFFFFFF, 0x8FFFFFFF,
};

/*
w0   w1   w2   w3  w4  w5
w6   w7   w8   w9  w10 w11
w12  w13  w14  w15 w16 w17
w18  w19  w20  w21 w22 w23
*/
/*
0 0 c c c c
n n n n 0 0
0 0 0 0 k k
k k k k k k 
*/
void InitState(word32 state[STATE_SIZE], const word32 key[KEY_SIZE], const word32 nonce[NONCE_SIZE]) {
    state[0] = 0x00;
    state[1] = 0x00;
    state[2] = 0x01;
    state[3] = 0x02;
    state[4] = 0x03;
    state[5] = 0x04;
    state[6] = nonce[0];
    state[7] = nonce[1];
    state[8] = nonce[2];
    state[9] = nonce[3];
    state[10] = 0x00;
    state[11] = 0x00;
    state[12] = 0x00;
    state[13] = 0x00;
    state[14] = 0x00;
    state[15] = 0x00;
    state[16] = key[0];
    state[17] = key[1];
    state[18] = key[2];
    state[19] = key[3];
    state[20] = key[4];
    state[21] = key[5];
    state[22] = key[6];
    state[23] = key[7];
}

void WDL(word32 state[STATE_SIZE]) {
    state[0] = state[0] + ROTL32(state[STATE_SIZE-1], 11);
    for(int i = 1; i < STATE_SIZE; i++) {
        state[i] += ROTL32(state[i-1], 11);
    }

    state[STATE_SIZE-1] = state[STATE_SIZE-1] + ROTL32(state[0], 19);
    for(int i = STATE_SIZE - 2; i >= 0; i--) {
        state[i] += ROTL32(state[i+1], 19);
    }
}

void GSL(word32 state[STATE_SIZE]) {
    word32 t1, t2, t3;

    // ROT ROWS
    t1 = state[6];
    state[6] = state[7];
    state[7] = state[8];
    state[8] = state[9];
    state[9] = state[10];
    state[10] = state[11];
    state[11] = t1;
    
    t1 = state[12];
    t2 = state[13];
    state[12] = state[14];
    state[13] = state[15];
    state[14] = state[16];
    state[15] = state[17];
    state[16] = t1;
    state[17] = t2;

    t1 = state[18];
    t2 = state[19];
    t3 = state[20];
    state[18] = state[21];
    state[19] = state[22];
    state[20] = state[23];
    state[21] = t1;
    state[22] = t2;
    state[23] = t3;

    // ROT COL
    t1 = state[1];
    state[1] = state[7];
    state[7] = state[13];
    state[13] = state[19];
    state[19] = t1;

    t1 = state[2];
    t2 = state[8];
    state[2] = state[14];
    state[8] = state[20];
    state[14] = t1;
    state[19] = t2;

    t1 = state[3];
    t2 = state[9];
    t3 = state[15];
    state[3] = state[21];
    state[9] = t1;
    state[15] = t2;
    state[21] = t3;

    t1 = state[5];
    state[5] = state[11];
    state[11] = state[17];
    state[17] = state[23];
    state[23] = t1;
}

#define CCL_ROW(w0, w1, w2, w3, w4, w5) \
    t0 = w0;                            \
    t1 = w1;                            \
    w0 ^= (~w1) & w2;                   \
    w1 ^= (~w2) & w3;                   \
    w2 ^= (~w3) & w4;                   \
    w3 ^= (~w4) & t0;                   \
    w4 ^= (~t0) & t1;

void CCL(word32 state[STATE_SIZE]) {
    word32 t0, t1;
    CCL_ROW(state[0],  state[1],  state[2],  state[3],  state[4],  state[5]);
    CCL_ROW(state[6],  state[7],  state[8],  state[9],  state[10], state[11]);
    CCL_ROW(state[12], state[13], state[14], state[15], state[16], state[17]);
    CCL_ROW(state[18], state[19], state[20], state[21], state[22], state[23]);
}

void RIL(word32 state[STATE_SIZE], word32 r) {
    state[0] ^= RC[0];
}

void Permultion(word32 state[STATE_SIZE])
{
    for (int i = 0; i < NUM_ROUND; i++)
    {
        RIL(state, i);
        GSL(state);
        CCL(state);
        WDL(state);
    }
}


/*
w0   w1   w2   w3  w4   w5   w6  
w7   w8   w9  w10  w11  w12  w13 
w14  w15  w16 w17  w18  w19  w20  
w21  w22  w23 w24  w25  w26  w27
*/
void WDL2(word32 state[STATE_SIZE]) {
    state[0] += ROTL32(state[6], 11);
    state[1] += ROTL32(state[0], 11);
    state[2] += ROTL32(state[1], 11);
    state[3] += ROTL32(state[2], 11);
    state[4] += ROTL32(state[3], 11);
    state[5] += ROTL32(state[4], 11);
    state[6] += ROTL32(state[5], 11);

    state[7]  += ROTL32(state[13], 17);
    state[8]  += ROTL32(state[7],  17);
    state[9]  += ROTL32(state[8],  17);
    state[10] += ROTL32(state[9],  17);
    state[11] += ROTL32(state[10], 17);
    state[12] += ROTL32(state[11], 17);
    state[13] += ROTL32(state[12], 17);

    state[14] += ROTL32(state[20], 19);
    state[15] += ROTL32(state[14], 19);
    state[16] += ROTL32(state[15], 19);
    state[17] += ROTL32(state[16], 19);
    state[18] += ROTL32(state[17], 19);
    state[19] += ROTL32(state[18], 19);
    state[20] += ROTL32(state[19], 19);

    state[21] += ROTL32(state[27], 13);
    state[22] += ROTL32(state[21], 13);
    state[23] += ROTL32(state[22], 13);
    state[24] += ROTL32(state[23], 13);
    state[25] += ROTL32(state[24], 13);
    state[26] += ROTL32(state[25], 13);
    state[27] += ROTL32(state[26], 13);
}

void GSL2(word32 state[STATE_SIZE]) {
    word32 t1, t2, t3;

    // ROT COL
    t1 = state[1];
    state[1] = state[8];
    state[8] = state[15];
    state[15] = state[22];
    state[22] = t1;

    t1 = state[2];
    t2 = state[9];
    state[2] = state[16];
    state[9] = state[23];
    state[16] = t1;
    state[23] = t2;

    t1 = state[3];
    t2 = state[10];
    t3 = state[17];
    state[3] = state[24];
    state[10] = t1;
    state[17] = t2;
    state[24] = t3;

    t1 = state[6];
    state[6] = state[13];
    state[13] = state[20];
    state[20] = state[27];
    state[27] = t1;
}

void Perm2(word32 state[STATE_SIZE]) {
    WDL2(state);
    GSL2(state);
}



































word32 key[KEY_SIZE]{0};
word32 nonce[NONCE_SIZE]{0};
word32 state[STATE_SIZE];
int wordRead = 0;

void IncNonce() {
    for(int i = 0; i < NONCE_SIZE; i++) {
        nonce[i]++;
        if(nonce[i] != 0)
            break;
    }
}

void RunPerm() {
    Permultion(state);
    IncNonce();
}

void SetupPerm() {
    InitState(state, key, nonce);
    RunPerm();
}

word32 GetNextWord() {
    if(wordRead == 16) {
        wordRead = -1;
        RunPerm();
    }

    wordRead++;
    return state[wordRead];
}
