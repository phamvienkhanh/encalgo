
typedef unsigned int word32;

#define STATE_SIZE 28
#define STATE_COL 7
#define STATE_ROW 4
#define KEY_SIZE 8
#define NONCE_SIZE 4
#define NUM_ROUND 20


word32 GetNextWord();
void SetupPerm();

void Perm2(word32 state[STATE_SIZE]);
