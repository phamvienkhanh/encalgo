#include <iostream>
#include <cstdlib>

#include "pvkenc.h"

extern "C" {
#include "unif01.h"
#include "bbattery.h"
}

unsigned int myrand(void)
{
    return GetNextWord();
}

word32 state2[STATE_SIZE]{0};
word32 readword2 = 16;
word32 myrand2() {
    if(readword2 == 16) {
        readword2 = -1;

        Perm2(state2);
        Perm2(state2);
        Perm2(state2);
        // Perm2(state2);
        // Perm2(state2);

        // Perm2(state2);
        // Perm2(state2);
        // Perm2(state2);
        // Perm2(state2);
        // Perm2(state2);
    }

    readword2++;
    return state2[readword2];
}

void printWord(word32 w) {
    printf("%.8x\n", w);
}

void printState(word32 state[STATE_SIZE]) {
    for(int i = 0; i < STATE_SIZE; i++) {
        if(i % STATE_COL == 0 && i != 0) {
            printf("\n");
        }

        printf("%.8x ", state[i]);
    }

    printf("\n");
}



int main(int, char**) {
    state2[0] = 1;
    Perm2(state2);
    Perm2(state2);
    Perm2(state2);
    printState(state2);

    // SetupPerm();

    // unif01_Gen *gen;
    // const char* name = "PVK Perm";
    // gen = unif01_CreateExternGenBits((char*)name, myrand2);
    // bbattery_SmallCrush(gen);
    // unif01_DeleteExternGenBits(gen);

    return 0;
}
